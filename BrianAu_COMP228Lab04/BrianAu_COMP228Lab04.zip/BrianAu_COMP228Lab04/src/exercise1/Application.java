/*
 * Created By: Brian Au
 * Student ID: 300962933
 * S2018 - COMP 228 - Programming 2 - Assignment 4 - Lab04
 * Wallace Balaniuc
 *
 */

package exercise1;

public class Application {
    public static void main (String [] args) {
        GUI mainApplication = new GUI();
        mainApplication.setSize(800,400);
        mainApplication.setVisible(true);
    }
}
